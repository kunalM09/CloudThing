﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TravelContact
{
    public class TravelbyContact : IPlugin
    {
        private IPluginExecutionContext context = null;
        public void Execute(IServiceProvider serviceProvider)
        {
            context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serivceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serivceFactory.CreateOrganizationService(null);
            
            ITracingService tracing = serviceProvider.GetService(typeof(ITracingService)) as ITracingService;



            try
            {
                
                EntityReference target = (EntityReference)context.InputParameters["Target"];
                tracing.Trace(target.Name);

                
                if (context.MessageName == "Associate" && (target.LogicalName == "contact" || target.LogicalName == "ct_orderregister"))
                {
                    
                    Relationship relationShip = (Relationship)context.InputParameters["Relationship"];
                    tracing.Trace(relationShip.SchemaName);
                   
                    EntityReferenceCollection relatedentities = (EntityReferenceCollection)context.InputParameters["RelatedEntities"];
                    foreach (EntityReference relatedEntity in relatedentities)
                    {
                        tracing.Trace(relationShip.SchemaName);
                        
                        if (relatedEntity.LogicalName == "ct_orderregister" && relationShip.SchemaName == "ct_ct_orderregister_contact")
                        {
                            Guid relatedEntotyID = relatedEntity.Id;
                            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='ct_orderregister'>
                                        <attribute name='ct_name' />
                                        <attribute name='ct_orderstatus' />
                                        <attribute name='ct_orderdate' />
                                        <attribute name='ct_destination' />
                                        <attribute name='ct_amount' />
                                        <order attribute='ct_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='ct_orderregisterid' operator='eq' value='" + relatedEntotyID + @"' />
                                        </filter>
                                      </entity>
                                    </fetch>";
                            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                            int orderstatus=0;
                            var amountorder=0;
                            if (result.Entities.Count > 0)
                            {
                                foreach (var entity in result.Entities)
                                {

                                    if (entity.Attributes.Contains("ct_orderstatus"))
                                    {
                                        orderstatus = (int)entity.GetAttributeValue<OptionSetValue>("ct_orderstatus").Value;
                                    }
                                    if (entity.Attributes.Contains("ct_amount"))
                                    {
                                        amountorder = (int)entity.GetAttributeValue<Money>("ct_amount").Value;
                                    }
                                }
                            }

                            Entity contact = new Entity("contact");
                            contact.Id = target.Id;
                            string fetchXml2 = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='contact'>
                                        <attribute name='fullname' />
                                        <attribute name='contactid' />
                                        <attribute name='ct_neworders' />
                                        <attribute name='ct_completedorders' />
                                        <attribute name='ct_cancelledorders' />
                                        <attribute name='ct_actualsalesamount' />
                                        <attribute name='ct_activeorders' />
                                        <order attribute='fullname' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='contactid' operator='eq' value='" + target.Id + @"' />
                                        </filter>
                                      </entity>
                                    </fetch>";
                            EntityCollection result2 = service.RetrieveMultiple(new FetchExpression(fetchXml2));
                            int ct_neworders = 0;
                            int ct_completedorders=0;
                            int ct_cancelledorders = 0;
                            int ct_actualsalesamount = 0;
                            int ct_activeorders = 0;
                            if (result2.Entities.Count > 0)
                            {
                                foreach (var entity in result2.Entities)
                                {
                                   // Entity PreOrder = context.PreEntityImages["PreImage"];

                                    //if (PreOrder.Attributes.Contains("ct_neworders") || PreOrder.Attributes.Contains("ct_completedorders") || PreOrder.Attributes.Contains("ct_cancelledorders") || PreOrder.Attributes.Contains("ct_actualsalesamount") || PreOrder.Attributes.Contains("ct_activeorders"))
                                    //{
                                        ct_neworders = (int)entity.GetAttributeValue<int>("ct_neworders");
                                        ct_completedorders = (int)entity.GetAttributeValue<int>("ct_completedorders");
                                        ct_cancelledorders = (int)entity.GetAttributeValue<int>("ct_cancelledorders");
                                    if (entity.Attributes.Contains("ct_actualsalesamount"))
                                    {
                                        ct_actualsalesamount = (int)entity.GetAttributeValue<Money>("ct_actualsalesamount").Value;
                                    }
                                        
                                        ct_activeorders = (int)entity.GetAttributeValue<int>("ct_activeorders");
                                    //}
                                }
                            }
                            if (orderstatus==1)
                            {
                               
                                contact["ct_neworders"] = ++ct_neworders;
                            }
                            else if (orderstatus == 2)
                            {
                                contact["ct_activeorders"] = ++ct_activeorders;
                            }
                            else if (orderstatus == 3)
                            {
                                contact["ct_cancelledorders"] = ++ct_cancelledorders;
                            }
                            else if (orderstatus == 4)
                            {
                                contact["ct_completedorders"] = ++ct_completedorders;
                            }
                            contact["ct_actualsalesamount"] = (decimal)ct_actualsalesamount + (decimal)amountorder;
                            service.Update(contact);

                        }
                    }
                }
                else if (context.MessageName == "Disassociate" && (target.LogicalName == "contact" || target.LogicalName == "ct_orderregister"))
                {

                    Relationship relationShip = (Relationship)context.InputParameters["Relationship"];
                    tracing.Trace(relationShip.SchemaName);

                    EntityReferenceCollection relatedentities = (EntityReferenceCollection)context.InputParameters["RelatedEntities"];
                    foreach (EntityReference relatedEntity in relatedentities)
                    {
                        tracing.Trace(relationShip.SchemaName);

                        if (relatedEntity.LogicalName == "ct_orderregister" && relationShip.SchemaName == "ct_ct_orderregister_contact")
                        {
                            Guid relatedEntotyID = relatedEntity.Id;
                            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='ct_orderregister'>
                                        <attribute name='ct_name' />
                                        <attribute name='ct_orderstatus' />
                                        <attribute name='ct_orderdate' />
                                        <attribute name='ct_destination' />
                                        <attribute name='ct_amount' />
                                        <order attribute='ct_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='ct_orderregisterid' operator='eq' value='" + relatedEntotyID + @"' />
                                        </filter>
                                      </entity>
                                    </fetch>";
                            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                            int orderstatus = 0;
                            var amountorder = 0;
                            if (result.Entities.Count > 0)
                            {
                                foreach (var entity in result.Entities)
                                {

                                    if (entity.Attributes.Contains("ct_orderstatus"))
                                    {
                                        orderstatus = (int)entity.GetAttributeValue<OptionSetValue>("ct_orderstatus").Value;
                                    }
                                    if (entity.Attributes.Contains("ct_amount"))
                                    {
                                        amountorder = (int)entity.GetAttributeValue<Money>("ct_amount").Value;
                                    }
                                }
                            }

                            Entity contact = new Entity("contact");
                            contact.Id = target.Id;
                            string fetchXml2 = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='contact'>
                                        <attribute name='fullname' />
                                        <attribute name='contactid' />
                                        <attribute name='ct_neworders' />
                                        <attribute name='ct_completedorders' />
                                        <attribute name='ct_cancelledorders' />
                                        <attribute name='ct_actualsalesamount' />
                                        <attribute name='ct_activeorders' />
                                        <order attribute='fullname' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='contactid' operator='eq' value='" + target.Id + @"' />
                                        </filter>
                                      </entity>
                                    </fetch>";
                            EntityCollection result2 = service.RetrieveMultiple(new FetchExpression(fetchXml2));
                            int ct_neworders = 0;
                            int ct_completedorders = 0;
                            int ct_cancelledorders = 0;
                            int ct_actualsalesamount = 0;
                            int ct_activeorders = 0;
                            if (result2.Entities.Count > 0)
                            {
                                foreach (var entity in result2.Entities)
                                {
                                    // Entity PreOrder = context.PreEntityImages["PreImage"];

                                    //if (PreOrder.Attributes.Contains("ct_neworders") || PreOrder.Attributes.Contains("ct_completedorders") || PreOrder.Attributes.Contains("ct_cancelledorders") || PreOrder.Attributes.Contains("ct_actualsalesamount") || PreOrder.Attributes.Contains("ct_activeorders"))
                                    //{
                                    ct_neworders = (int)entity.GetAttributeValue<int>("ct_neworders");
                                    ct_completedorders = (int)entity.GetAttributeValue<int>("ct_completedorders");
                                    ct_cancelledorders = (int)entity.GetAttributeValue<int>("ct_cancelledorders");
                                    if (entity.Attributes.Contains("ct_actualsalesamount"))
                                    {
                                        ct_actualsalesamount = (int)entity.GetAttributeValue<Money>("ct_actualsalesamount").Value;
                                    }

                                    ct_activeorders = (int)entity.GetAttributeValue<int>("ct_activeorders");
                                    //}
                                }
                            }
                            if (orderstatus == 1)
                            {

                                contact["ct_neworders"] = --ct_neworders;
                            }
                            else if (orderstatus == 2)
                            {
                                contact["ct_activeorders"] = --ct_activeorders;
                            }
                            else if (orderstatus == 3)
                            {
                                contact["ct_cancelledorders"] = --ct_cancelledorders;
                            }
                            else if (orderstatus == 4)
                            {
                                contact["ct_completedorders"] = --ct_completedorders;
                            }
                            contact["ct_actualsalesamount"] = (decimal)ct_actualsalesamount - (decimal)amountorder;
                            service.Update(contact);

                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            
        }
    }
}
