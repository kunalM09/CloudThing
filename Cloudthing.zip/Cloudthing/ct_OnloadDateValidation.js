function Onchange(executionContext) {
    debugger;
    var formContext = executionContext.getFormContext();

    var orderdate = formContext.getAttribute("ct_orderdate").getValue();
    var TodayDate = new Date();
    if (orderdate < TodayDate) {
        var orderdate = formContext.getAttribute("ct_orderdate").setValue(TodayDate);
        formContext.ui.setFormNotification("Past Dates not allowed", "WARNING", '2')
    }
    else if (orderdate >= TodayDate) {
        formContext.ui.clearFormNotification('2');
    }
}